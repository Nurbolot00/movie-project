import React from 'react';
import Button from '../UI/button/Button';
import './Card.css'

const Card = (props) => {
    let {data} = props


    return(
        <div className='movie-list'>
            <li className='movie-element'>
                <div className='movie-element__image'>
                    <img src={data.img} alt={data.title} />
                </div>
                <div className='movie-element__info'>
                    <h2>{data.title}</h2>
                    <p>{data.rating}/5</p>
                    <Button color="#d30808">DELETE</Button>
                    <Button color=' #00329e'>EDIT</Button>
                </div>
           
                
            </li>
        </div>  
        
        
    );

};

export default Card;