import React from 'react';
import Card from '../card/Card';
import {movies} from '../movies/movies'



const Main = () => {
    return (
        <div>
            {movies.map((element,index) =>{
                return <Card data ={element} key={index}/>
            })
             };   
        </div>
         );
 };
export default Main;