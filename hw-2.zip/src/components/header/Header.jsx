import React from 'react';
import Button from '../UI/button/Button';
import './Header.css'

const Header = () => {
    return (
        <div>
             <header>
             <h1>Favorite Movies</h1>
             <Button color='#f67722'>ADD MOVIE</Button>
            </header>
        </div>
    );
};

export default Header;